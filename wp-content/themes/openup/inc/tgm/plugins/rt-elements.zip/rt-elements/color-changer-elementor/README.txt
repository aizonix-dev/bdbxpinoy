=== Plugin Name ===
Contributors: elementinvader
Donate link: elementinvader.com
Tags: elementor,color,changer,replacer
Requires at least: 5.2
Tested up to: 6.1
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin will help you Replace / Change Colors defined inside Elementor Editor automatically on all pages

== Description ==

https://www.youtube.com/watch?v=3sw7SKm0DZI

Plugin will help you Replace Colors defined inside Elementor Editor

Plugin will autodetect colors used in elementor on different pages

Then you will be able to change this colors globally on all pages

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `color-changer-elementor.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Is this compatible with all themes? =

This plugin don't care about theme, it simply replace colors defined inside elementor editor, if color define in other place or useing some default element colors, will not be able to change it.

== Screenshots ==

1. Change colors screenshot

== Changelog ==

= 1.0 =
* Init version
