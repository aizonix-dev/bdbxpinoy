<?php
defined( 'ABSPATH' ) or exit;

class RSHF_Settings{
    public function __construct(){
        //
        
    }
}
