<?php
/**
 * The template for General Footer.
 *
 * This is the template that footer layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<script>
	(function( $ ) {
		'use strict';
		$( window ).load(function() {

		});
	})( jQuery );
</script>